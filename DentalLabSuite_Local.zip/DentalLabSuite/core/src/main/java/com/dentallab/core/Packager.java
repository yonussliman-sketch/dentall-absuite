package com.dentallab.core;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import androidx.core.content.FileProvider;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * تبادل الحالات بين تطبيق العيادة وتطبيق المعمل بملف ZIP واحد (manifest.json + الملفات)
 * يُرسل عبر واتساب أو أي تطبيق مشاركة، ويُستورد من الطرف الآخر.
 *  - cases   : من العيادة إلى المعمل (عدة حالات + مواعيد + ملفات)
 *  - updates : من المعمل إلى العيادة (الحالة والسعر وملاحظات + الدفعات + حالة المواعيد)
 */
public class Packager {
    public static class Result { public int cases, appts, updates, payments; }

    private static String nz(String s) { return s == null ? "" : s; }

    private static File exportsDir(Context c) {
        File d = new File(c.getCacheDir(), "exports");
        d.mkdirs();
        File[] old = d.listFiles();
        if (old != null) for (File f : old) f.delete();
        return d;
    }

    private static String stamp() { return new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date()); }

    private static String ascii(String s, String fallback) {
        String r = nz(s).replaceAll("[^A-Za-z0-9]+", "_").replaceAll("^_+|_+$", "");
        return r.isEmpty() ? fallback : r;
    }

    private static void putManifest(ZipOutputStream z, JSONObject root) throws Exception {
        z.putNextEntry(new ZipEntry("manifest.json"));
        z.write(root.toString().getBytes(StandardCharsets.UTF_8));
        z.closeEntry();
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
    }

    // ---------------- العيادة ← المعمل ----------------
    public static File exportCases(Context c, List<CaseItem> cases, List<Appointment> appts) throws Exception {
        JSONObject root = new JSONObject();
        root.put("type", "cases");
        root.put("v", 1);
        JSONObject clinic = new JSONObject();
        clinic.put("uid", Profile.uid(c)); clinic.put("name", Profile.name(c)); clinic.put("phone", Profile.e164(c));
        root.put("clinic", clinic);
        JSONArray ca = new JSONArray();
        for (CaseItem k : cases) {
            JSONObject o = new JSONObject();
            o.put("uid", k.uid); o.put("ref", nz(k.patientRef)); o.put("work", k.workType); o.put("teeth", nz(k.teeth));
            o.put("shade", nz(k.shade)); o.put("due", nz(k.dueDate)); o.put("notes", nz(k.notes));
            o.put("urgent", k.urgent); o.put("created", k.createdAt);
            JSONArray fa = new JSONArray();
            for (FileStore.Item it : FileStore.parse(k.filesJson)) {
                JSONObject f = new JSONObject();
                f.put("n", it.name); f.put("p", it.path); f.put("s", it.size);
                fa.put(f);
            }
            o.put("files", fa);
            ca.put(o);
        }
        root.put("cases", ca);
        JSONArray aa = new JSONArray();
        for (Appointment a : appts) {
            JSONObject o = new JSONObject();
            o.put("uid", a.uid); o.put("ref", nz(a.patientRef)); o.put("date", nz(a.date)); o.put("time", nz(a.time));
            o.put("created", a.createdAt);
            aa.put(o);
        }
        root.put("appointments", aa);

        File out = new File(exportsDir(c), "DentalLab_" + ascii(Profile.name(c), "Clinic") + "_" + stamp() + ".zip");
        try (ZipOutputStream z = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(out)))) {
            putManifest(z, root);
            for (CaseItem k : cases) {
                for (FileStore.Item it : FileStore.parse(k.filesJson)) {
                    File src = new File(c.getFilesDir(), it.path);
                    if (!src.exists() || !it.path.startsWith("cases/")) continue;
                    z.putNextEntry(new ZipEntry("files/" + it.path.substring("cases/".length())));
                    try (InputStream in = new BufferedInputStream(new FileInputStream(src))) { copy(in, z); }
                    z.closeEntry();
                }
            }
        }
        return out;
    }

    // ---------------- المعمل ← العيادة ----------------
    public static File exportUpdates(Context c, Clinic clinic) throws Exception {
        AppDao dao = AppDatabase.get(c).dao();
        JSONObject root = new JSONObject();
        root.put("type", "updates");
        root.put("v", 1);
        root.put("clinicUid", clinic.uid);
        JSONArray ca = new JSONArray();
        for (CaseItem k : dao.casesOfClinic(clinic.uid)) {
            JSONObject o = new JSONObject();
            o.put("uid", k.uid); o.put("status", k.status); o.put("price", k.price); o.put("labNote", nz(k.labNote));
            ca.put(o);
        }
        root.put("cases", ca);
        JSONArray aa = new JSONArray();
        for (Appointment a : dao.apptsOfClinic(clinic.uid)) {
            JSONObject o = new JSONObject();
            o.put("uid", a.uid); o.put("status", a.status);
            aa.put(o);
        }
        root.put("appointments", aa);
        JSONArray pa = new JSONArray();
        for (Payment p : dao.paymentsOfClinic(clinic.uid)) {
            JSONObject o = new JSONObject();
            o.put("uid", p.uid); o.put("amount", p.amount); o.put("note", nz(p.note)); o.put("created", p.createdAt);
            pa.put(o);
        }
        root.put("payments", pa);
        File out = new File(exportsDir(c), "DentalLab_Update_" + ascii(clinic.name, "Clinic") + "_" + stamp() + ".zip");
        try (ZipOutputStream z = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(out)))) {
            putManifest(z, root);
        }
        return out;
    }

    // ---------------- الاستيراد ----------------
    public static Result importFrom(Context c, Uri uri, boolean lab) throws Exception {
        AppDao dao = AppDatabase.get(c).dao();
        Result res = new Result();
        try (InputStream raw = c.getContentResolver().openInputStream(uri)) {
            if (raw == null) throw new IOException("no stream");
            ZipInputStream z = new ZipInputStream(new BufferedInputStream(raw));
            ZipEntry e = z.getNextEntry();
            if (e == null || !"manifest.json".equals(e.getName())) throw new IOException("not a package");
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            copy(z, bo);
            JSONObject root = new JSONObject(new String(bo.toByteArray(), StandardCharsets.UTF_8));
            String type = root.getString("type");

            if ("cases".equals(type)) {
                if (!lab) throw new IOException("wrong app");
                String base = new File(c.getFilesDir(), "cases").getCanonicalPath() + File.separator;
                while ((e = z.getNextEntry()) != null) {
                    String name = e.getName();
                    if (e.isDirectory() || !name.startsWith("files/")) continue;
                    File dest = new File(c.getFilesDir(), "cases/" + name.substring(6));
                    if (!dest.getCanonicalPath().startsWith(base)) continue; // حماية من المسارات الخبيثة
                    dest.getParentFile().mkdirs();
                    try (FileOutputStream out = new FileOutputStream(dest)) { copy(z, out); }
                }
                JSONObject cl = root.getJSONObject("clinic");
                Clinic clinic = new Clinic();
                clinic.uid = cl.getString("uid"); clinic.name = cl.optString("name"); clinic.phone = cl.optString("phone");
                dao.upsertClinic(clinic);
                JSONArray ca = root.optJSONArray("cases");
                for (int i = 0; ca != null && i < ca.length(); i++) {
                    JSONObject o = ca.getJSONObject(i);
                    if (dao.caseByUid(o.getString("uid")) != null) continue;
                    CaseItem k = new CaseItem();
                    k.uid = o.getString("uid");
                    k.clinicUid = clinic.uid; k.clinicName = clinic.name; k.clinicPhone = clinic.phone;
                    k.patientRef = o.optString("ref"); k.workType = o.optInt("work"); k.teeth = o.optString("teeth");
                    k.shade = o.optString("shade"); k.dueDate = o.optString("due"); k.notes = o.optString("notes");
                    k.urgent = o.optBoolean("urgent"); k.createdAt = o.optLong("created", System.currentTimeMillis());
                    k.updatedAt = System.currentTimeMillis(); k.status = 1;
                    java.util.ArrayList<FileStore.Item> files = new java.util.ArrayList<>();
                    JSONArray fa = o.optJSONArray("files");
                    for (int j = 0; fa != null && j < fa.length(); j++) {
                        JSONObject f = fa.getJSONObject(j);
                        FileStore.Item it = new FileStore.Item();
                        it.name = f.optString("n"); it.path = f.optString("p"); it.size = f.optLong("s");
                        if (new File(c.getFilesDir(), it.path).exists()) files.add(it);
                    }
                    k.filesJson = FileStore.toJson(files);
                    dao.insertCase(k);
                    res.cases++;
                }
                JSONArray aa = root.optJSONArray("appointments");
                for (int i = 0; aa != null && i < aa.length(); i++) {
                    JSONObject o = aa.getJSONObject(i);
                    if (dao.apptByUid(o.getString("uid")) != null) continue;
                    Appointment a = new Appointment();
                    a.uid = o.getString("uid"); a.clinicUid = clinic.uid; a.clinicName = clinic.name; a.clinicPhone = clinic.phone;
                    a.patientRef = o.optString("ref"); a.date = o.optString("date"); a.time = o.optString("time");
                    a.status = 0; a.sent = true; a.createdAt = o.optLong("created", System.currentTimeMillis());
                    dao.insertAppt(a);
                    res.appts++;
                }
            } else if ("updates".equals(type)) {
                if (lab) throw new IOException("wrong app");
                if (!Profile.uid(c).equals(root.optString("clinicUid"))) throw new IOException("other clinic");
                JSONArray ca = root.optJSONArray("cases");
                for (int i = 0; ca != null && i < ca.length(); i++) {
                    JSONObject o = ca.getJSONObject(i);
                    CaseItem k = dao.caseByUid(o.getString("uid"));
                    if (k == null) continue;
                    int st = o.optInt("status", k.status);
                    if (k.status != st || k.price != o.optDouble("price", k.price) || !nz(k.labNote).equals(o.optString("labNote"))) res.updates++;
                    k.status = Math.max(st, 1); k.price = o.optDouble("price", k.price); k.labNote = o.optString("labNote");
                    k.updatedAt = System.currentTimeMillis();
                    dao.updateCase(k);
                }
                JSONArray aa = root.optJSONArray("appointments");
                for (int i = 0; aa != null && i < aa.length(); i++) {
                    JSONObject o = aa.getJSONObject(i);
                    Appointment a = dao.apptByUid(o.getString("uid"));
                    if (a == null) continue;
                    if (a.status != o.optInt("status")) res.updates++;
                    a.status = o.optInt("status");
                    dao.updateAppt(a);
                }
                JSONArray pa = root.optJSONArray("payments");
                for (int i = 0; pa != null && i < pa.length(); i++) {
                    JSONObject o = pa.getJSONObject(i);
                    if (dao.paymentByUid(o.getString("uid")) != null) continue;
                    Payment p = new Payment();
                    p.uid = o.getString("uid"); p.clinicUid = Profile.uid(c); p.amount = o.optDouble("amount");
                    p.note = o.optString("note"); p.createdAt = o.optLong("created", System.currentTimeMillis());
                    dao.insertPayment(p);
                    res.payments++;
                }
            } else throw new IOException("unknown type");
        }
        return res;
    }

    public static void share(Context c, File f, int titleRes) {
        Uri u = FileProvider.getUriForFile(c, c.getPackageName() + ".files", f);
        Intent s = new Intent(Intent.ACTION_SEND).setType("application/zip")
                .putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        c.startActivity(Intent.createChooser(s, c.getString(titleRes)));
    }
}
