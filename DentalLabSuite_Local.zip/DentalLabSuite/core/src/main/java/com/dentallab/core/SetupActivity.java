package com.dentallab.core;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

/** أول تشغيل: اسم الطبيب/المعمل + الدولة + رقم الهاتف. وتُستخدم أيضاً لتعديل الملف الشخصي. */
public class SetupActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_setup);
        Edge.apply(this);
        final boolean lab = getIntent().getBooleanExtra("lab", false);
        final boolean edit = getIntent().getBooleanExtra("edit", false);
        if (edit && getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        if (!edit && getSupportActionBar() != null) getSupportActionBar().hide();
        setTitle(R.string.more_profile);

        TextView title = findViewById(R.id.tvTitle), sub = findViewById(R.id.tvSub);
        EditText name = findViewById(R.id.etName);
        PhoneField phone = findViewById(R.id.phone);
        Button save = findViewById(R.id.btnSave);
        title.setText(lab ? R.string.setup_title_lab : R.string.setup_title_clinic);
        sub.setText(lab ? R.string.setup_sub_lab : R.string.setup_sub_clinic);
        name.setHint(lab ? R.string.hint_name_lab : R.string.hint_name_clinic);
        save.setText(edit ? R.string.btn_save : R.string.btn_start);
        if (Profile.exists(this)) {
            name.setText(Profile.name(this));
            phone.set(Profile.iso(this), Profile.national(this));
        }
        save.setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            if (n.isEmpty()) { Ui.toast(this, R.string.err_name); return; }
            if (!phone.isValid()) { Ui.toast(this, R.string.err_phone); return; }
            Profile.save(this, n, phone.getIso(), phone.getNational(), phone.getE164());
            if (edit) { finish(); return; }
            Intent i = getPackageManager().getLaunchIntentForPackage(getPackageName());
            if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); startActivity(i); }
            finish();
        });
    }

    @Override public boolean onSupportNavigateUp() { finish(); return true; }
}
