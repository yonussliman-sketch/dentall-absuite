package com.dentallab.core;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** قائمة الطلبات: العيادة ترى طلباتها، والمعمل يرى الكل مع بحث وفلترة بالحالة */
public class OrdersFragment extends Fragment {
    private ListView list;
    private Spinner spFilter;
    private EditText etSearch;
    private ListenerRegistration reg;
    private final List<Order> all = new ArrayList<>();
    private List<Order> shown = new ArrayList<>();
    private boolean lab;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup c, @Nullable Bundle s) {
        View v = inf.inflate(R.layout.fragment_orders, c, false);
        lab = Session.isLab(requireContext());
        list = v.findViewById(R.id.list);
        list.setEmptyView(v.findViewById(R.id.empty));
        spFilter = v.findViewById(R.id.spFilter);
        etSearch = v.findViewById(R.id.etSearch);

        if (lab) {
            v.findViewById(R.id.filterBar).setVisibility(View.VISIBLE);
            List<String> opts = new ArrayList<>();
            opts.add("كل الحالات");
            for (String st : Ui.STATUSES) opts.add(st);
            spFilter.setAdapter(new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_dropdown_item, opts));
            spFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override public void onItemSelected(AdapterView<?> p, View view, int pos, long id) { apply(); }
                @Override public void onNothingSelected(AdapterView<?> p) { }
            });
            etSearch.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence a, int b, int c2, int d) { }
                @Override public void onTextChanged(CharSequence a, int b, int c2, int d) { apply(); }
                @Override public void afterTextChanged(Editable e) { }
            });
        }

        list.setOnItemClickListener((p, view, pos, id) ->
                startActivity(new Intent(requireContext(), OrderDetailActivity.class).putExtra("id", shown.get(pos).id)));

        Query q = Repo.db().collection("orders");
        if (!lab) q = q.whereEqualTo("clinicId", Repo.uid());
        reg = q.addSnapshotListener((snap, e) -> {
            if (snap == null || !isAdded()) return;
            all.clear();
            all.addAll(snap.toObjects(Order.class));
            Collections.sort(all, (a, b) -> Long.compare(b.createdAt, a.createdAt));
            apply();
        });
        return v;
    }

    private void apply() {
        if (!isAdded()) return;
        String q = lab ? etSearch.getText().toString().trim().toLowerCase(Locale.getDefault()) : "";
        int f = lab ? spFilter.getSelectedItemPosition() : 0;
        shown = new ArrayList<>();
        List<CardAdapter.Row> rows = new ArrayList<>();
        for (Order o : all) {
            if (f > 0 && !Ui.STATUSES[f - 1].equals(o.status)) continue;
            String hay = (Ui.nz(o.patientName) + " " + Ui.nz(o.clinicName)).toLowerCase(Locale.getDefault());
            if (!q.isEmpty() && !hay.contains(q)) continue;
            shown.add(o);
            int nf = o.files == null ? 0 : o.files.size();
            String sub = "🦷 الأسنان: " + Ui.nz(o.teeth)
                    + (lab ? "\n🏥 " + Ui.nz(o.clinicName) : "")
                    + "\n📅 التسليم: " + Ui.nz(o.dueDate) + (nf > 0 ? "   📎 " + nf + " ملف" : "");
            rows.add(new CardAdapter.Row((o.urgent ? "⚡ " : "") + o.patientName + " — " + Ui.nz(o.workType),
                    sub, o.status, Ui.statusColor(o.status)));
        }
        list.setAdapter(new CardAdapter(requireContext(), rows));
    }

    @Override public void onDestroyView() {
        if (reg != null) reg.remove();
        super.onDestroyView();
    }
}
