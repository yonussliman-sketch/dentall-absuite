package com.dentallab.core;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;

@Dao
public interface AppDao {
    @Insert long insertCase(CaseItem c);
    @Update void updateCase(CaseItem c);
    @Delete void deleteCase(CaseItem c);
    @Query("SELECT * FROM cases ORDER BY createdAt DESC") List<CaseItem> allCases();
    @Query("SELECT * FROM cases WHERE id = :id LIMIT 1") CaseItem caseById(long id);
    @Query("SELECT * FROM cases WHERE uid = :uid LIMIT 1") CaseItem caseByUid(String uid);
    @Query("SELECT * FROM cases WHERE status = 0 ORDER BY createdAt") List<CaseItem> unsentCases();
    @Query("SELECT * FROM cases WHERE clinicUid = :u ORDER BY createdAt DESC") List<CaseItem> casesOfClinic(String u);

    @Insert void insertAppt(Appointment a);
    @Update void updateAppt(Appointment a);
    @Delete void deleteAppt(Appointment a);
    @Query("SELECT * FROM appointments ORDER BY createdAt DESC") List<Appointment> allAppts();
    @Query("SELECT * FROM appointments WHERE uid = :uid LIMIT 1") Appointment apptByUid(String uid);
    @Query("SELECT * FROM appointments WHERE sent = 0") List<Appointment> unsentAppts();
    @Query("SELECT * FROM appointments WHERE clinicUid = :u") List<Appointment> apptsOfClinic(String u);

    @Insert void insertPayment(Payment p);
    @Query("SELECT * FROM payments ORDER BY createdAt DESC") List<Payment> allPayments();
    @Query("SELECT * FROM payments WHERE uid = :uid LIMIT 1") Payment paymentByUid(String uid);
    @Query("SELECT * FROM payments WHERE clinicUid = :u ORDER BY createdAt DESC") List<Payment> paymentsOfClinic(String u);

    @Insert(onConflict = OnConflictStrategy.REPLACE) void upsertClinic(Clinic c);
    @Query("SELECT * FROM clinics ORDER BY name") List<Clinic> allClinics();
    @Query("SELECT * FROM clinics WHERE uid = :u LIMIT 1") Clinic clinic(String u);

    @Insert void insertItem(InventoryItem i);
    @Update void updateItem(InventoryItem i);
    @Delete void deleteItem(InventoryItem i);
    @Query("SELECT * FROM inventory ORDER BY name") List<InventoryItem> allItems();
}
