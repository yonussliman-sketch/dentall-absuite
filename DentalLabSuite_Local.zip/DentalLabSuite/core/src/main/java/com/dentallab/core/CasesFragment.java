package com.dentallab.core;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** قائمة الحالات. العيادة: إرسال الحالات الجديدة دفعة واحدة. المعمل: استيراد + بحث + فلترة بالحالة. */
public class CasesFragment extends Fragment {
    private boolean lab;
    private ListView list;
    private Spinner spFilter;
    private EditText etSearch;
    private Button btnPrimary;
    private List<CaseItem> all = new ArrayList<>();
    private List<CaseItem> shown = new ArrayList<>();

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup c, @Nullable Bundle s) {
        View v = inf.inflate(R.layout.fragment_cases, c, false);
        final Host host = (Host) requireActivity();
        lab = host.isLab();
        list = v.findViewById(R.id.list);
        list.setEmptyView(v.findViewById(R.id.empty));
        spFilter = v.findViewById(R.id.spFilter);
        etSearch = v.findViewById(R.id.etSearch);
        btnPrimary = v.findViewById(R.id.btnPrimary);
        Button btnImport = v.findViewById(R.id.btnImport);

        if (lab) {
            btnPrimary.setText(R.string.btn_import_cases);
            btnPrimary.setOnClickListener(x -> host.pickImport());
            btnImport.setVisibility(View.GONE);
            v.findViewById(R.id.filterBar).setVisibility(View.VISIBLE);
            List<String> opts = new ArrayList<>();
            opts.add(getString(R.string.all_statuses));
            for (String st : Ui.statusLabels(requireContext(), 1)) opts.add(st);
            spFilter.setAdapter(new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_dropdown_item, opts));
            spFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override public void onItemSelected(AdapterView<?> p, View view, int pos, long id) { apply(); }
                @Override public void onNothingSelected(AdapterView<?> p) { }
            });
            etSearch.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence a, int b, int c2, int d) { }
                @Override public void onTextChanged(CharSequence a, int b, int c2, int d) { apply(); }
                @Override public void afterTextChanged(Editable e) { }
            });
        } else {
            btnPrimary.setOnClickListener(x -> host.sendNew());
            btnImport.setOnClickListener(x -> host.pickImport());
        }
        list.setOnItemClickListener((p, view, pos, id) ->
                startActivity(new Intent(requireContext(), CaseDetailActivity.class)
                        .putExtra("id", shown.get(pos).id).putExtra("lab", lab)));
        return v;
    }

    @Override public void onResume() { super.onResume(); load(); }

    private void load() {
        all = AppDatabase.get(requireContext()).dao().allCases();
        if (!lab) {
            int n = AppDatabase.get(requireContext()).dao().unsentCases().size()
                    + AppDatabase.get(requireContext()).dao().unsentAppts().size();
            btnPrimary.setText(getString(R.string.btn_send_new, n));
            btnPrimary.setEnabled(n > 0);
        }
        apply();
    }

    private void apply() {
        if (!isAdded()) return;
        String q = lab ? etSearch.getText().toString().trim().toLowerCase(Locale.getDefault()) : "";
        int f = lab ? spFilter.getSelectedItemPosition() : 0;
        shown = new ArrayList<>();
        List<CardAdapter.Row> rows = new ArrayList<>();
        for (CaseItem k : all) {
            if (f > 0 && k.status != f) continue;
            String hay = (Ui.nz(k.clinicName) + " " + Ui.nz(k.patientRef) + " " + Ui.nz(k.teeth)).toLowerCase(Locale.getDefault());
            if (!q.isEmpty() && !hay.contains(q)) continue;
            shown.add(k);
            int nf = FileStore.parse(k.filesJson).size();
            String ref = Ui.nz(k.patientRef).trim();
            String sub = (lab ? Ui.workLabel(requireContext(), k.workType) + (ref.isEmpty() ? "" : " \u2014 " + ref) + "\n" : "")
                    + "\uD83E\uDDB7 " + Ui.nz(k.teeth)
                    + (Ui.nz(k.dueDate).isEmpty() ? "" : "\n\uD83D\uDCC5 " + k.dueDate)
                    + (nf > 0 ? "   \uD83D\uDCCE " + nf : "");
            rows.add(new CardAdapter.Row((k.urgent ? "\u26A1 " : "") + Ui.caseTitle(requireContext(), k, lab), sub,
                    Ui.statusLabel(requireContext(), k.status), Ui.statusColor(k.status)));
        }
        list.setAdapter(new CardAdapter(requireContext(), rows));
    }
}
