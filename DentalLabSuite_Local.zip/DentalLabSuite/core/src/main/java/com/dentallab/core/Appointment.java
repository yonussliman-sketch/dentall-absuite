package com.dentallab.core;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/** status: 0 بانتظار التأكيد، 1 مؤكد، 2 مرفوض */
@Entity(tableName = "appointments")
public class Appointment {
    @PrimaryKey(autoGenerate = true) public long id;
    public String uid, clinicUid, clinicName, clinicPhone, patientRef, date, time;
    public int status;
    public boolean sent;
    public long createdAt;
}
