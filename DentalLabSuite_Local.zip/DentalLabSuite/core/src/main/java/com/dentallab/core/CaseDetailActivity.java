package com.dentallab.core;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import java.util.ArrayList;
import java.util.List;

public class CaseDetailActivity extends AppCompatActivity {
    private CaseItem k;
    private boolean lab;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_case_detail);
        Edge.apply(this);
        setTitle(R.string.title_case);
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        lab = getIntent().getBooleanExtra("lab", false);
        k = AppDatabase.get(this).dao().caseById(getIntent().getLongExtra("id", -1));
        if (k == null) { finish(); return; }
        render();
    }

    private void render() {
        TextView title = findViewById(R.id.tvTitle);
        title.setText((k.urgent ? "\u26A1 " : "") + Ui.caseTitle(this, k, lab));
        TextView st = findViewById(R.id.tvStatus);
        st.setText(Ui.statusLabel(this, k.status));
        st.setBackground(Ui.pill(Ui.statusColor(k.status)));

        String ref = Ui.nz(k.patientRef).trim();
        StringBuilder info = new StringBuilder();
        if (lab) info.append("\uD83D\uDCDE ").append(Ui.nz(k.clinicPhone)).append('\n');
        info.append("\uD83D\uDD27 ").append(getString(R.string.lbl_work)).append(": ").append(Ui.workLabel(this, k.workType)).append('\n');
        if (!ref.isEmpty()) info.append("\uD83D\uDC64 ").append(getString(R.string.lbl_ref)).append(": ").append(ref).append('\n');
        info.append("\uD83C\uDFA8 ").append(getString(R.string.lbl_shade)).append(": ")
                .append(Ui.nz(k.shade).isEmpty() ? getString(R.string.unspecified) : k.shade).append('\n');
        info.append("\uD83D\uDCC5 ").append(getString(R.string.lbl_due)).append(": ").append(Ui.nz(k.dueDate)).append('\n');
        info.append("\uD83D\uDCB0 ").append(getString(R.string.lbl_price)).append(": ")
                .append(k.price > 0 ? Ui.money(k.price) : getString(R.string.price_none)).append('\n');
        info.append("\uD83D\uDCDD ").append(getString(R.string.lbl_notes)).append(": ").append(Ui.nz(k.notes));
        if (!Ui.nz(k.labNote).isEmpty()) info.append("\n\uD83D\uDCAC ").append(getString(R.string.lbl_lab_note)).append(": ").append(k.labNote);
        ((TextView) findViewById(R.id.tvInfo)).setText(info.toString());

        TeethChartView chart = findViewById(R.id.teeth);
        chart.setReadOnly(true);
        chart.setSelectedFromCsv(k.teeth);
        ((TextView) findViewById(R.id.tvTeeth)).setText(getString(R.string.teeth_selected, Ui.nz(k.teeth).replace(",", ", ")));

        LinearLayout box = findViewById(R.id.filesBox);
        box.removeAllViews();
        List<FileStore.Item> files = FileStore.parse(k.filesJson);
        findViewById(R.id.tvFilesTitle).setVisibility(files.isEmpty() ? View.GONE : View.VISIBLE);
        for (FileStore.Item it : files) {
            MaterialButton btn = new MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle);
            btn.setText("\uD83D\uDCC4 " + it.name + "  (" + FileStore.human(it.size) + ")");
            btn.setAllCaps(false);
            btn.setOnClickListener(v -> FileStore.openOrShare(this, it));
            box.addView(btn);
        }

        if (lab) {
            findViewById(R.id.panelLab).setVisibility(View.VISIBLE);
            Spinner sp = findViewById(R.id.spStatus);
            sp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, Ui.statusLabels(this, 1)));
            sp.setSelection(Math.max(0, k.status - 1));
            EditText price = findViewById(R.id.etPrice);
            EditText note = findViewById(R.id.etLabNote);
            if (k.price > 0) price.setText(Ui.money(k.price));
            note.setText(Ui.nz(k.labNote));
            findViewById(R.id.btnUpdate).setOnClickListener(v -> {
                k.status = sp.getSelectedItemPosition() + 1;
                k.price = Ui.num(price.getText().toString());
                k.labNote = note.getText().toString().trim();
                k.updatedAt = System.currentTimeMillis();
                AppDatabase.get(this).dao().updateCase(k);
                Ui.toast(this, R.string.toast_updated);
                render();
            });
            findViewById(R.id.btnWa).setOnClickListener(v ->
                    Ui.whatsapp(this, k.clinicPhone, getString(R.string.msg_to_doctor, Ui.workLabel(this, k.workType))));
            findViewById(R.id.btnCall).setOnClickListener(v -> Ui.call(this, k.clinicPhone));
        } else {
            android.widget.Button send = findViewById(R.id.btnSend);
            send.setVisibility(View.VISIBLE);
            send.setText(k.status == 0 ? R.string.btn_send_lab : R.string.btn_resend);
            send.setOnClickListener(v -> {
                List<CaseItem> one = new ArrayList<>();
                one.add(k);
                Actions.sendCases(this, one, new ArrayList<>(), this::reload);
            });
        }
        findViewById(R.id.btnDelete).setOnClickListener(v -> Ui.confirm(this, R.string.confirm_delete, () -> {
            FileStore.deleteCase(this, k.uid);
            AppDatabase.get(this).dao().deleteCase(k);
            finish();
        }));
    }

    private void reload() {
        CaseItem fresh = AppDatabase.get(this).dao().caseById(k.id);
        if (fresh != null) { k = fresh; render(); }
    }

    @Override public boolean onSupportNavigateUp() { finish(); return true; }
}
