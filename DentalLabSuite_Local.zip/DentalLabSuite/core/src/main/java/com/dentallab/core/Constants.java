package com.dentallab.core;

public class Constants {
    /** رقم التواصل والاستفسار (يظهر في آخر شاشة "المزيد" فقط) */
    public static final String CONTACT_PHONE = "+967777531968";
}
