package com.dentallab.core;
import com.google.firebase.firestore.DocumentId;
import java.util.ArrayList;
import java.util.List;

public class Order {
    @DocumentId public String id;
    public String clinicId, clinicName, clinicPhone, patientName, workType, teeth, shade, dueDate, notes, labNote, status;
    public double price;
    public boolean urgent;
    public long createdAt;
    public List<CaseFile> files = new ArrayList<>();
    public Order() {}
}
