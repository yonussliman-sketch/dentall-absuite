package com.dentallab.core;
import android.content.Context;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import java.util.ArrayList;
import java.util.List;

/** إشعارات فورية أثناء عمل التطبيق (والخلفية عبر Cloud Functions) */
public class Watcher {
    private interface OnChange { void run(DocumentChange c); }

    public static List<ListenerRegistration> start(Context ctx, boolean lab) {
        Context app = ctx.getApplicationContext();
        List<ListenerRegistration> regs = new ArrayList<>();
        Query orders = Repo.db().collection("orders");
        Query appts = Repo.db().collection("appointments");
        if (!lab) {
            orders = orders.whereEqualTo("clinicId", Repo.uid());
            appts = appts.whereEqualTo("clinicId", Repo.uid());
        }
        regs.add(watch(orders, c -> {
            Order o = c.getDocument().toObject(Order.class);
            if (!lab && c.getType() == DocumentChange.Type.MODIFIED)
                Notifier.show(app, "تحديث طلب", "طلب " + o.patientName + ": " + o.status);
            if (lab && c.getType() == DocumentChange.Type.ADDED)
                Notifier.show(app, (o.urgent ? "⚡ " : "") + "طلب جديد", "من " + o.clinicName + " — " + o.patientName);
        }));
        regs.add(watch(appts, c -> {
            Appointment a = c.getDocument().toObject(Appointment.class);
            if (!lab && c.getType() == DocumentChange.Type.MODIFIED)
                Notifier.show(app, "تحديث موعد", "موعد " + a.patientName + ": " + a.status);
            if (lab && c.getType() == DocumentChange.Type.ADDED)
                Notifier.show(app, "طلب موعد قياس", "من " + a.clinicName + " في " + a.date + " " + a.time);
        }));
        return regs;
    }

    private static ListenerRegistration watch(Query q, OnChange cb) {
        final boolean[] first = {true};
        return q.addSnapshotListener((snap, e) -> {
            if (snap == null) return;
            if (first[0]) { first[0] = false; return; }
            for (DocumentChange c : snap.getDocumentChanges()) {
                if (c.getDocument().getMetadata().hasPendingWrites()) continue;
                cb.run(c);
            }
        });
    }
}
