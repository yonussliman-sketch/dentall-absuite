package com.dentallab.core;
import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** تشغيل عمل ثقيل (نسخ ملفات / ضغط) في خيط خلفي ثم العودة للواجهة */
public class Bg {
    private static final ExecutorService EX = Executors.newSingleThreadExecutor();
    private static final Handler H = new Handler(Looper.getMainLooper());

    public interface Work<T> { T run() throws Exception; }
    public interface Done<T> { void done(T result, Exception error); }

    public static <T> void run(Work<T> w, Done<T> d) {
        EX.execute(() -> {
            T r = null;
            Exception err = null;
            try { r = w.run(); } catch (Exception e) { err = e; }
            final T rr = r;
            final Exception ee = err;
            H.post(() -> d.done(rr, ee));
        });
    }
}
