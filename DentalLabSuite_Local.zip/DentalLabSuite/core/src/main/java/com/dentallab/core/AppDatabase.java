package com.dentallab.core;
import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {CaseItem.class, Appointment.class, Payment.class, Clinic.class, InventoryItem.class},
        version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    public abstract AppDao dao();
    private static AppDatabase instance;

    public static synchronized AppDatabase get(Context c) {
        if (instance == null) {
            instance = Room.databaseBuilder(c.getApplicationContext(), AppDatabase.class, "dentallab.db")
                    .allowMainThreadQueries() // بيانات صغيرة؛ العمليات الثقيلة (الملفات) تعمل في خيط خلفي
                    .build();
        }
        return instance;
    }
}
