package com.dentallab.core;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.webkit.MimeTypeMap;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.FileProvider;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** تخزين ملفات الحالات (STL / صور / PDF / أي صيغة) داخل التطبيق */
public class FileStore {
    public static class Item {
        public String name, path;
        public long size;
    }

    public static List<Item> parse(String json) {
        List<Item> out = new ArrayList<>();
        if (json == null || json.isEmpty()) return out;
        try {
            JSONArray a = new JSONArray(json);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Item it = new Item();
                it.name = o.optString("n"); it.path = o.optString("p"); it.size = o.optLong("s");
                out.add(it);
            }
        } catch (Exception ignored) { }
        return out;
    }

    public static String toJson(List<Item> items) {
        JSONArray a = new JSONArray();
        try {
            for (Item it : items) {
                JSONObject o = new JSONObject();
                o.put("n", it.name); o.put("p", it.path); o.put("s", it.size);
                a.put(o);
            }
        } catch (Exception ignored) { }
        return a.toString();
    }

    public static String displayName(Context c, Uri u) {
        try (Cursor q = c.getContentResolver().query(u, null, null, null, null)) {
            if (q != null && q.moveToFirst()) {
                int i = q.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0 && q.getString(i) != null) return q.getString(i);
            }
        } catch (Exception ignored) { }
        return "file_" + System.currentTimeMillis();
    }

    public static long sizeOf(Context c, Uri u) {
        try (Cursor q = c.getContentResolver().query(u, null, null, null, null)) {
            if (q != null && q.moveToFirst()) {
                int i = q.getColumnIndex(OpenableColumns.SIZE);
                if (i >= 0) return q.getLong(i);
            }
        } catch (Exception ignored) { }
        return 0;
    }

    public static String safe(String name) {
        String s = name.replaceAll("[^A-Za-z0-9._-]", "_");
        return s.length() > 80 ? s.substring(s.length() - 80) : s;
    }

    public static String human(long b) {
        if (b < 1024) return b + " B";
        if (b < 1024 * 1024) return String.format(Locale.US, "%.1f KB", b / 1024.0);
        return String.format(Locale.US, "%.1f MB", b / 1048576.0);
    }

    /** ينسخ ملفاً مختاراً إلى مخزن التطبيق (يُستدعى من خيط خلفي) */
    public static Item copyIn(Context c, Uri uri, String caseUid, int index) throws IOException {
        String name = displayName(c, uri);
        String rel = "cases/" + caseUid + "/" + index + "_" + safe(name);
        File dest = new File(c.getFilesDir(), rel);
        dest.getParentFile().mkdirs();
        try (InputStream in = c.getContentResolver().openInputStream(uri);
             FileOutputStream out = new FileOutputStream(dest)) {
            if (in == null) throw new IOException("no stream");
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
        Item it = new Item();
        it.name = name; it.path = rel; it.size = dest.length();
        return it;
    }

    public static void deleteCase(Context c, String caseUid) {
        File dir = new File(c.getFilesDir(), "cases/" + caseUid);
        File[] fs = dir.listFiles();
        if (fs != null) for (File f : fs) f.delete();
        dir.delete();
    }

    private static String mimeOf(String name) {
        int i = name.lastIndexOf('.');
        if (i > 0) {
            String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substring(i + 1).toLowerCase(Locale.US));
            if (m != null) return m;
        }
        return "application/octet-stream";
    }

    /** فتح الملف ببرنامج مناسب أو مشاركته */
    public static void openOrShare(Context c, Item it) {
        File f = new File(c.getFilesDir(), it.path);
        if (!f.exists()) { Ui.toast(c, R.string.err_file_missing); return; }
        Uri u = FileProvider.getUriForFile(c, c.getPackageName() + ".files", f);
        new AlertDialog.Builder(c).setTitle(it.name)
                .setItems(new String[]{c.getString(R.string.file_open), c.getString(R.string.file_share)}, (d, w) -> {
                    if (w == 0) {
                        Intent i = new Intent(Intent.ACTION_VIEW).setDataAndType(u, mimeOf(it.name))
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        try { c.startActivity(i); } catch (Exception e) { share(c, u, it.name); }
                    } else share(c, u, it.name);
                })
                .setNegativeButton(R.string.btn_close, null).show();
    }

    private static void share(Context c, Uri u, String name) {
        Intent s = new Intent(Intent.ACTION_SEND).setType("application/octet-stream")
                .putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        c.startActivity(Intent.createChooser(s, name));
    }
}
