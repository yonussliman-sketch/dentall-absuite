package com.dentallab.core;
import android.content.Context;
import android.content.SharedPreferences;

public class Session {
    private static SharedPreferences p(Context c) { return c.getSharedPreferences("session", Context.MODE_PRIVATE); }
    public static void save(Context c, String name, String role, String phone) {
        p(c).edit().putString("name", name).putString("role", role).putString("phone", phone).apply();
    }
    public static boolean loggedIn(Context c) { return p(c).contains("role"); }
    public static String name(Context c) { return p(c).getString("name", ""); }
    public static String phone(Context c) { return p(c).getString("phone", ""); }
    public static boolean isLab(Context c) { return "lab".equals(p(c).getString("role", "")); }
    public static void clear(Context c) { p(c).edit().clear().apply(); }
}
