package com.dentallab.core;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import java.util.List;

/** المزيد: الملف الشخصي، اللغة، (المخزون للمعمل)، حول التطبيق — وفي آخر الشاشة رقم التواصل والاستفسار */
public class MoreFragment extends Fragment {
    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup c, @Nullable Bundle s) {
        View v = inf.inflate(R.layout.fragment_list, c, false);
        v.findViewById(R.id.fab).setVisibility(View.GONE);
        v.findViewById(R.id.empty).setVisibility(View.GONE);
        final Host host = (Host) requireActivity();
        ListView list = v.findViewById(R.id.list);

        final List<Integer> actions = new ArrayList<>();
        List<CardAdapter.Row> rows = new ArrayList<>();
        rows.add(new CardAdapter.Row("\uD83D\uDC64  " + getString(R.string.more_profile), Profile.name(requireContext()), null, 0));
        actions.add(0);
        rows.add(new CardAdapter.Row("\uD83C\uDF10  " + getString(R.string.more_language), null, null, 0));
        actions.add(1);
        if (host.isLab()) {
            rows.add(new CardAdapter.Row("\uD83D\uDCE6  " + getString(R.string.more_inventory), null, null, 0));
            actions.add(2);
        }
        rows.add(new CardAdapter.Row("\u2139\uFE0F  " + getString(R.string.more_about), null, null, 0));
        actions.add(3);

        View footer = inf.inflate(R.layout.view_contact, list, false);
        ((TextView) footer.findViewById(R.id.tvNumber)).setText(Constants.CONTACT_PHONE);
        footer.findViewById(R.id.btnWa).setOnClickListener(x ->
                Ui.whatsapp(requireContext(), Constants.CONTACT_PHONE, getString(R.string.contact_msg)));
        footer.findViewById(R.id.btnCall).setOnClickListener(x -> Ui.call(requireContext(), Constants.CONTACT_PHONE));
        list.addFooterView(footer, null, false);
        list.setAdapter(new CardAdapter(requireContext(), rows));

        list.setOnItemClickListener((p, view, pos, id) -> {
            if (pos >= actions.size()) return;
            int a = actions.get(pos);
            if (a == 0) startActivity(new Intent(requireContext(), SetupActivity.class)
                    .putExtra("edit", true).putExtra("lab", host.isLab()));
            else if (a == 1) Lang.showDialog(requireActivity());
            else if (a == 2) host.openInventory();
            else about();
        });
        return v;
    }

    private void about() {
        String ver = "";
        try {
            PackageInfo pi = requireContext().getPackageManager().getPackageInfo(requireContext().getPackageName(), 0);
            ver = pi.versionName;
        } catch (Exception ignored) { }
        new AlertDialog.Builder(requireContext()).setTitle(R.string.more_about)
                .setMessage(getString(R.string.about_text, ver))
                .setPositiveButton(R.string.btn_close, null).show();
    }
}
