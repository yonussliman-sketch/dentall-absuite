package com.dentallab.core;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "inventory")
public class InventoryItem {
    @PrimaryKey(autoGenerate = true) public long id;
    public String name;
    public int quantity;
}
