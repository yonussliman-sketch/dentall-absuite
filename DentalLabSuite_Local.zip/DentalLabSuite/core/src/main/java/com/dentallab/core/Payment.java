package com.dentallab.core;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "payments")
public class Payment {
    @PrimaryKey(autoGenerate = true) public long id;
    public String uid, clinicUid, note;
    public double amount;
    public long createdAt;
}
