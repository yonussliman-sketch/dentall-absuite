package com.dentallab.core;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.OpenableColumns;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import java.util.Locale;

public class FileUtil {
    public interface Progress { void onProgress(int percent); }
    public interface Done { void onDone(CaseFile file, Exception error); }

    public static String name(Context c, Uri u) {
        try (Cursor q = c.getContentResolver().query(u, null, null, null, null)) {
            if (q != null && q.moveToFirst()) {
                int i = q.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0 && q.getString(i) != null) return q.getString(i);
            }
        } catch (Exception ignored) { }
        return "file_" + System.currentTimeMillis();
    }

    public static long size(Context c, Uri u) {
        try (Cursor q = c.getContentResolver().query(u, null, null, null, null)) {
            if (q != null && q.moveToFirst()) {
                int i = q.getColumnIndex(OpenableColumns.SIZE);
                if (i >= 0) return q.getLong(i);
            }
        } catch (Exception ignored) { }
        return 0;
    }

    public static String human(long b) {
        if (b < 1024) return b + " B";
        if (b < 1024 * 1024) return String.format(Locale.US, "%.1f KB", b / 1024.0);
        return String.format(Locale.US, "%.1f MB", b / 1048576.0);
    }

    /** رفع أي ملف (STL / صور / PDF / ZIP ...) إلى Firebase Storage */
    public static void upload(Context c, Uri uri, String name, long size, Progress p, Done d) {
        String safe = name.replaceAll("[^A-Za-z0-9._-]", "_");
        String path = "cases/" + Repo.uid() + "/" + System.currentTimeMillis() + "_" + safe;
        StorageReference ref = Repo.storage().getReference(path);
        UploadTask t = ref.putFile(uri);
        t.addOnProgressListener(s -> p.onProgress((int) (100.0 * s.getBytesTransferred() / Math.max(1, s.getTotalByteCount()))));
        t.addOnSuccessListener(s -> {
            CaseFile f = new CaseFile();
            f.name = name; f.path = path; f.size = size;
            d.onDone(f, null);
        }).addOnFailureListener(e -> d.onDone(null, e));
    }

    public static void download(Context c, CaseFile f) {
        Repo.storage().getReference(f.path).getDownloadUrl().addOnSuccessListener(u -> {
            try {
                DownloadManager.Request r = new DownloadManager.Request(u);
                r.setTitle(f.name);
                r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, f.name.replaceAll("[\\\\/:*?\"<>|]", "_"));
                ((DownloadManager) c.getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
                Ui.toast(c, "بدأ التنزيل — سيظهر في مجلد التنزيلات");
            } catch (Exception e) {
                Intent i = new Intent(Intent.ACTION_VIEW, u);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(i);
            }
        }).addOnFailureListener(e -> Ui.toast(c, "تعذّر التنزيل: " + e.getLocalizedMessage()));
    }
}
