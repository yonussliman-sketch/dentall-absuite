package com.dentallab.core;
import android.app.Activity;
import android.net.Uri;
import androidx.appcompat.app.AlertDialog;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** عمليات الإرسال والاستيراد المشتركة */
public class Actions {
    /** العيادة: إرسال كل الحالات والمواعيد غير المرسلة في ملف واحد */
    public static void sendNew(Activity a, Runnable done) {
        AppDao dao = AppDatabase.get(a).dao();
        sendCases(a, dao.unsentCases(), dao.unsentAppts(), done);
    }

    public static void sendCases(Activity a, List<CaseItem> cases, List<Appointment> appts, Runnable done) {
        if (cases.isEmpty() && appts.isEmpty()) { Ui.toast(a, R.string.err_nothing_to_send); return; }
        AlertDialog dlg = Ui.busy(a, R.string.msg_building);
        final List<CaseItem> cs = new ArrayList<>(cases);
        final List<Appointment> as = new ArrayList<>(appts);
        Bg.run(() -> Packager.exportCases(a, cs, as), (File f, Exception err) -> {
            dlg.dismiss();
            if (err != null) { Ui.toast(a, R.string.err_generic); return; }
            AppDao dao = AppDatabase.get(a).dao();
            for (CaseItem k : cs) if (k.status == 0) { k.status = 1; k.updatedAt = System.currentTimeMillis(); dao.updateCase(k); }
            for (Appointment ap : as) if (!ap.sent) { ap.sent = true; dao.updateAppt(ap); }
            Packager.share(a, f, R.string.share_title);
            if (done != null) done.run();
        });
    }

    /** المعمل: إرسال تحديثات عيادة (حالات + أسعار + دفعات) */
    public static void sendUpdates(Activity a, Clinic clinic) {
        AlertDialog dlg = Ui.busy(a, R.string.msg_building);
        Bg.run(() -> Packager.exportUpdates(a, clinic), (File f, Exception err) -> {
            dlg.dismiss();
            if (err != null) { Ui.toast(a, R.string.err_generic); return; }
            Packager.share(a, f, R.string.share_title);
        });
    }

    public static void importUri(Activity a, Uri uri, boolean lab, Runnable done) {
        AlertDialog dlg = Ui.busy(a, R.string.msg_importing);
        Bg.run(() -> Packager.importFrom(a, uri, lab), (Packager.Result r, Exception err) -> {
            dlg.dismiss();
            if (err != null || r == null) { Ui.toast(a, R.string.err_import); return; }
            if (lab) Ui.toast(a, a.getString(R.string.import_ok_cases, r.cases, r.appts));
            else Ui.toast(a, a.getString(R.string.import_ok_updates, r.updates, r.payments));
            if (done != null) done.run();
        });
    }
}
