package com.dentallab.core;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/** حالة واحدة: نوع العمل + الأسنان + الملفات. status: 0 غير مُرسلة، 1 جديد، 2 قيد التصنيع، 3 فحص الجودة، 4 جاهز، 5 تم التسليم */
@Entity(tableName = "cases", indices = {@Index(value = "uid", unique = true)})
public class CaseItem {
    @PrimaryKey(autoGenerate = true) public long id;
    public String uid, clinicUid, clinicName, clinicPhone, patientRef, teeth, shade, dueDate, notes, labNote, filesJson;
    public int workType, status;
    public boolean urgent;
    public double price;
    public long createdAt, updatedAt;
}
