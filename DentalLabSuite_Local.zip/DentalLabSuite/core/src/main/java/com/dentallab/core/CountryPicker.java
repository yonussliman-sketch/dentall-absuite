package com.dentallab.core;
import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import androidx.appcompat.app.AlertDialog;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** نافذة اختيار الدولة (علم + اسم بلغة التطبيق + رمز الاتصال) مع بحث */
public class CountryPicker {
    public interface OnPick { void pick(String iso); }

    public static void show(Context ctx, String selectedIso, OnPick cb) {
        Locale loc = ctx.getResources().getConfiguration().getLocales().get(0);
        final List<Countries.Country> all = Countries.all(loc);
        final List<Countries.Country> shown = new ArrayList<>(all);

        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * ctx.getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad / 2, pad, 0);
        EditText search = new EditText(ctx);
        search.setHint(R.string.hint_search_country);
        search.setSingleLine(true);
        ListView list = new ListView(ctx);
        root.addView(search);
        root.addView(list, new LinearLayout.LayoutParams(-1, (int) (380 * ctx.getResources().getDisplayMetrics().density)));

        final AlertDialog dlg = new AlertDialog.Builder(ctx).setTitle(R.string.title_country).setView(root)
                .setNegativeButton(R.string.btn_cancel, null).create();

        final Runnable refresh = () -> {
            List<String> labels = new ArrayList<>();
            for (Countries.Country c : shown) labels.add(c.label());
            list.setAdapter(new ArrayAdapter<>(ctx, android.R.layout.simple_list_item_1, labels));
        };
        refresh.run();
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {
                String q = s.toString().trim().toLowerCase(loc).replace("+", "");
                shown.clear();
                for (Countries.Country k : all)
                    if (q.isEmpty() || k.name.toLowerCase(loc).contains(q) || String.valueOf(k.dial).startsWith(q)
                            || k.iso.toLowerCase(Locale.US).equals(q)) shown.add(k);
                refresh.run();
            }
            @Override public void afterTextChanged(Editable s) { }
        });
        list.setOnItemClickListener((p, v, pos, id) -> { cb.pick(shown.get(pos).iso); dlg.dismiss(); });
        dlg.show();
    }
}
