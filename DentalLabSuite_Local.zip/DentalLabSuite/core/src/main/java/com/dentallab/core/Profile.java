package com.dentallab.core;
import android.content.Context;
import android.content.SharedPreferences;
import java.util.UUID;

/** ملف الطبيب/المعمل المحلي: الاسم + الدولة + الرقم */
public class Profile {
    private static SharedPreferences p(Context c) { return c.getSharedPreferences("profile", Context.MODE_PRIVATE); }
    public static boolean exists(Context c) { return p(c).contains("e164"); }
    public static String uid(Context c) {
        String u = p(c).getString("uid", null);
        if (u == null) { u = UUID.randomUUID().toString(); p(c).edit().putString("uid", u).apply(); }
        return u;
    }
    public static String name(Context c) { return p(c).getString("name", ""); }
    public static String iso(Context c) { return p(c).getString("iso", ""); }
    public static String national(Context c) { return p(c).getString("national", ""); }
    public static String e164(Context c) { return p(c).getString("e164", ""); }
    public static void save(Context c, String name, String iso, String national, String e164) {
        p(c).edit().putString("name", name).putString("iso", iso).putString("national", national).putString("e164", e164).apply();
    }
}
