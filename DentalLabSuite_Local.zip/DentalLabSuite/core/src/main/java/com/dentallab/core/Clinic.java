package com.dentallab.core;
import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "clinics")
public class Clinic {
    @PrimaryKey @NonNull public String uid = "";
    public String name, phone;
}
