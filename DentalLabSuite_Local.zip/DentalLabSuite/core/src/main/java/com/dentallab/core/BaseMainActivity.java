package com.dentallab.core;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.IntentCompat;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

/** الشاشة الرئيسية المشتركة: شريط التبويبات + الاستيراد + استقبال الملفات المشاركة */
public abstract class BaseMainActivity extends AppCompatActivity implements Host {
    protected BottomNavigationView nav;
    protected ExtendedFloatingActionButton fab;

    protected abstract int menuRes();
    protected abstract int firstItemId();
    protected abstract Fragment fragmentFor(int itemId);
    protected boolean fabVisibleFor(int itemId) { return false; }
    protected void onFabClick() { }

    private final ActivityResultLauncher<String[]> importPicker = registerForActivityResult(
            new ActivityResultContracts.OpenDocument(), uri -> { if (uri != null) importUri(uri); });

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (!Profile.exists(this)) {
            startActivity(new Intent(this, SetupActivity.class).putExtra("lab", isLab()));
            finish();
            return;
        }
        setContentView(R.layout.activity_main);
        setTitle("\uD83E\uDDB7 " + Profile.name(this));
        nav = findViewById(R.id.nav);
        fab = findViewById(R.id.fabNew);
        nav.inflateMenu(menuRes());
        fab.setOnClickListener(v -> onFabClick());
        nav.setOnItemSelectedListener(i -> { show(i.getItemId()); return true; });
        if (b == null) nav.setSelectedItemId(firstItemId());
        handleIntent(getIntent());
    }

    protected void show(int itemId) {
        fab.setVisibility(fabVisibleFor(itemId) ? View.VISIBLE : View.GONE);
        getSupportFragmentManager().beginTransaction().replace(R.id.container, fragmentFor(itemId)).commit();
    }

    protected void refresh() { show(nav.getSelectedItemId()); }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (nav != null) handleIntent(intent);
    }

    /** ملف ZIP مُشارَك أو مفتوح من واتساب/مدير الملفات */
    private void handleIntent(Intent i) {
        if (i == null) return;
        Uri u = null;
        if (Intent.ACTION_VIEW.equals(i.getAction())) u = i.getData();
        else if (Intent.ACTION_SEND.equals(i.getAction())) u = IntentCompat.getParcelableExtra(i, Intent.EXTRA_STREAM, Uri.class);
        if (u != null) {
            setIntent(new Intent(Intent.ACTION_MAIN));
            importUri(u);
        }
    }

    private void importUri(Uri uri) { Actions.importUri(this, uri, isLab(), this::refresh); }

    @Override public void pickImport() {
        importPicker.launch(new String[]{"application/zip", "application/x-zip-compressed", "application/octet-stream"});
    }
    @Override public void sendNew() { Actions.sendNew(this, this::refresh); }
    @Override public void openInventory() { }
}
