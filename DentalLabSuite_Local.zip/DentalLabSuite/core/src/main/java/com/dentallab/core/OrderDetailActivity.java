package com.dentallab.core;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import java.util.Arrays;

public class OrderDetailActivity extends AppCompatActivity {
    private String id;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_order_detail);
        setTitle("تفاصيل الطلب");
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        id = getIntent().getStringExtra("id");
        Repo.db().collection("orders").document(id).get().addOnSuccessListener(s -> {
            Order o = s.toObject(Order.class);
            if (o == null) { finish(); return; }
            show(o);
        });
    }

    private void show(Order o) {
        boolean lab = Session.isLab(this);
        ((TextView) findViewById(R.id.tvTitle)).setText((o.urgent ? "⚡ " : "") + o.patientName);
        TextView st = findViewById(R.id.tvStatus);
        st.setText(o.status);
        st.setBackground(Ui.pill(Ui.statusColor(o.status)));
        ((TextView) findViewById(R.id.tvInfo)).setText(
                "🏥 العيادة: " + Ui.nz(o.clinicName)
                + "\n🔧 نوع العمل: " + Ui.nz(o.workType)
                + "\n🎨 اللون: " + Ui.nz(o.shade)
                + "\n📅 التسليم: " + Ui.nz(o.dueDate)
                + "\n💰 السعر: " + (o.price > 0 ? Ui.money(o.price) : "لم يحدد بعد")
                + "\n📝 ملاحظات العيادة: " + Ui.nz(o.notes)
                + (Ui.nz(o.labNote).isEmpty() ? "" : "\n💬 ملاحظة المعمل: " + o.labNote));

        TeethChartView chart = findViewById(R.id.teeth);
        chart.setReadOnly(true);
        chart.setSelectedFromCsv(o.teeth);
        ((TextView) findViewById(R.id.tvTeeth)).setText("الأسنان: " + Ui.nz(o.teeth));

        LinearLayout box = findViewById(R.id.filesBox);
        box.removeAllViews();
        if (o.files == null || o.files.isEmpty()) {
            findViewById(R.id.tvFilesTitle).setVisibility(View.GONE);
        } else {
            for (CaseFile f : o.files) {
                MaterialButton btn = new MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle);
                btn.setText("⬇ " + f.name + "  (" + FileUtil.human(f.size) + ")");
                btn.setAllCaps(false);
                btn.setOnClickListener(v -> FileUtil.download(this, f));
                box.addView(btn);
            }
        }

        if (lab) {
            findViewById(R.id.panelLab).setVisibility(View.VISIBLE);
            Spinner sp = findViewById(R.id.spStatus);
            sp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, Ui.STATUSES));
            sp.setSelection(Math.max(Arrays.asList(Ui.STATUSES).indexOf(o.status), 0));
            EditText price = findViewById(R.id.etPrice);
            EditText note = findViewById(R.id.etLabNote);
            if (o.price > 0) price.setText(Ui.money(o.price));
            note.setText(Ui.nz(o.labNote));
            findViewById(R.id.btnUpdate).setOnClickListener(v ->
                Repo.db().collection("orders").document(id).update(
                        "status", Ui.STATUSES[sp.getSelectedItemPosition()],
                        "price", Ui.num(price.getText().toString()),
                        "labNote", note.getText().toString().trim(),
                        "updatedAt", System.currentTimeMillis())
                    .addOnSuccessListener(x -> { Ui.toast(this, "تم التحديث"); finish(); })
                    .addOnFailureListener(e -> Ui.toast(this, "فشل: " + e.getLocalizedMessage())));
            findViewById(R.id.btnWa).setOnClickListener(v ->
                    Ui.whatsapp(this, o.clinicPhone, "بخصوص طلب المريض " + o.patientName + ": "));
            findViewById(R.id.btnCall).setOnClickListener(v -> Ui.call(this, o.clinicPhone));
        } else if ("جديد".equals(o.status)) {
            View cancel = findViewById(R.id.btnCancel);
            cancel.setVisibility(View.VISIBLE);
            cancel.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("إلغاء الطلب؟")
                    .setPositiveButton("نعم، إلغاء", (d, w) ->
                            Repo.db().collection("orders").document(id).delete().addOnSuccessListener(x -> finish()))
                    .setNegativeButton("لا", null).show());
        }
    }

    @Override public boolean onSupportNavigateUp() { finish(); return true; }
}
