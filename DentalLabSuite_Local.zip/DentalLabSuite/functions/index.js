// إشعارات FCM الخلفية (تعمل والتطبيق مغلق). تتطلب خطة Blaze.
const { onDocumentCreated, onDocumentUpdated } = require("firebase-functions/v2/firestore");
const admin = require("firebase-admin");
admin.initializeApp();

const android = { notification: { channelId: "orders" } };

async function tokenOf(uid) {
  const u = await admin.firestore().doc(`users/${uid}`).get();
  return u.get("fcmToken");
}

// طلب جديد ← إشعار للمعمل
exports.onOrderCreated = onDocumentCreated("orders/{id}", async (event) => {
  const o = event.data.data();
  await admin.messaging().send({
    topic: "labs",
    notification: { title: o.urgent ? "⚡ طلب مستعجل" : "طلب جديد", body: `من ${o.clinicName} — ${o.patientName}` },
    android,
  });
});

// تغيّر حالة الطلب ← إشعار للعيادة
exports.onOrderUpdated = onDocumentUpdated("orders/{id}", async (event) => {
  const before = event.data.before.data();
  const after = event.data.after.data();
  if (before.status === after.status) return;
  const token = await tokenOf(after.clinicId);
  if (!token) return;
  await admin.messaging().send({
    token,
    notification: { title: "تحديث طلب", body: `طلب ${after.patientName}: ${after.status}` },
    android,
  });
});

// موعد جديد ← إشعار للمعمل
exports.onAppointmentCreated = onDocumentCreated("appointments/{id}", async (event) => {
  const a = event.data.data();
  await admin.messaging().send({
    topic: "labs",
    notification: { title: "طلب موعد قياس", body: `من ${a.clinicName} في ${a.date} ${a.time}` },
    android,
  });
});

// تغيّر حالة الموعد ← إشعار للعيادة
exports.onAppointmentUpdated = onDocumentUpdated("appointments/{id}", async (event) => {
  const before = event.data.before.data();
  const after = event.data.after.data();
  if (before.status === after.status) return;
  const token = await tokenOf(after.clinicId);
  if (!token) return;
  await admin.messaging().send({
    token,
    notification: { title: "تحديث موعد", body: `موعد ${after.patientName}: ${after.status}` },
    android,
  });
});
