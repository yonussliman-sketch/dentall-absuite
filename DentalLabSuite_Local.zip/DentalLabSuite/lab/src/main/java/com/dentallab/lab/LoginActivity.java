package com.dentallab.lab;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import com.dentallab.core.*;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.WriteBatch;
import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {
    private boolean registerMode = false;
    private EditText etName, etPhone, etEmail, etPassword;
    private Button btnLogin, btnToggle;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Repo.auth().getCurrentUser() != null && Session.loggedIn(this)) { openMain(); return; }
        setContentView(R.layout.activity_login);
        etName = findViewById(R.id.etName);
        etPhone = findViewById(R.id.etPhone);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnToggle = findViewById(R.id.btnToggle);
        btnToggle.setOnClickListener(v -> {
            registerMode = !registerMode;
            int vis = registerMode ? View.VISIBLE : View.GONE;
            etName.setVisibility(vis);
            etPhone.setVisibility(vis);
            btnLogin.setText(registerMode ? "إنشاء حساب المعمل" : "دخول");
            btnToggle.setText(registerMode ? "لديك حساب؟ سجّل الدخول" : "أول مرة؟ أنشئ حساب المعمل (مرة واحدة فقط)");
        });
        btnLogin.setOnClickListener(v -> submit());
    }

    private void submit() {
        String email = etEmail.getText().toString().trim();
        String pass = etPassword.getText().toString();
        String name = etName.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        if (email.isEmpty() || pass.length() < 6 || (registerMode && name.isEmpty())) {
            Ui.toast(this, "أكمل البيانات (كلمة المرور 6 أحرف على الأقل)");
            return;
        }
        btnLogin.setEnabled(false);
        if (registerMode) {
            Repo.auth().createUserWithEmailAndPassword(email, pass).addOnSuccessListener(r -> {
                String uid = Repo.uid();
                Map<String, Object> u = new HashMap<>();
                u.put("name", name); u.put("phone", phone); u.put("role", "lab"); u.put("email", email);
                Map<String, Object> owner = new HashMap<>();
                owner.put("uid", uid);
                WriteBatch wb = Repo.db().batch();
                wb.set(Repo.db().collection("users").document(uid), u);
                wb.set(Repo.db().collection("config").document("labOwner"), owner);
                wb.commit().addOnSuccessListener(x -> { Session.save(this, name, "lab", phone); openMain(); })
                        .addOnFailureListener(e -> {
                            // حساب المعمل موجود مسبقاً: احذف الحساب الذي أُنشئ للتو
                            FirebaseUser fu = Repo.auth().getCurrentUser();
                            if (fu != null) fu.delete();
                            btnLogin.setEnabled(true);
                            Ui.toast(this, "تم إنشاء حساب المعمل مسبقاً. سجّل الدخول بدلاً من ذلك.");
                        });
            }).addOnFailureListener(this::fail);
        } else {
            Repo.auth().signInWithEmailAndPassword(email, pass).addOnSuccessListener(r ->
                Repo.db().collection("users").document(Repo.uid()).get().addOnSuccessListener(s -> {
                    UserProfile p = s.toObject(UserProfile.class);
                    if (p == null || !"lab".equals(p.role)) {
                        Repo.auth().signOut();
                        btnLogin.setEnabled(true);
                        Ui.toast(this, "هذا الحساب غير مخصص لتطبيق المعمل");
                        return;
                    }
                    Session.save(this, p.name, "lab", Ui.nz(p.phone));
                    openMain();
                }).addOnFailureListener(this::fail)
            ).addOnFailureListener(this::fail);
        }
    }

    private void fail(Exception e) {
        btnLogin.setEnabled(true);
        Ui.toast(this, "خطأ: " + e.getLocalizedMessage());
    }
    private void openMain() { startActivity(new Intent(this, MainActivity.class)); finish(); }
}
