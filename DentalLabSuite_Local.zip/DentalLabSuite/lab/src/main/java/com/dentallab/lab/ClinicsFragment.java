package com.dentallab.lab;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import com.dentallab.core.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** الأطباء/العيادات: رصيد كل عيادة. اضغط لتسجيل دفعة أو إرسال التحديثات أو التواصل */
public class ClinicsFragment extends Fragment {
    private ListView list;
    private TextView header;
    private List<Clinic> clinics = new ArrayList<>();

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup c, @Nullable Bundle s) {
        View v = inf.inflate(R.layout.fragment_list, c, false);
        v.findViewById(R.id.fab).setVisibility(View.GONE);
        list = v.findViewById(R.id.list);
        list.setEmptyView(v.findViewById(R.id.empty));
        header = v.findViewById(R.id.header);
        header.setVisibility(View.VISIBLE);
        list.setOnItemClickListener((p, view, pos, id) -> options(clinics.get(pos)));
        load();
        return v;
    }

    private void load() {
        AppDao dao = AppDatabase.get(requireContext()).dao();
        clinics = dao.allClinics();
        double totDue = 0, totPaid = 0;
        List<CardAdapter.Row> rows = new ArrayList<>();
        for (Clinic cl : clinics) {
            double due = 0, paid = 0;
            for (CaseItem k : dao.casesOfClinic(cl.uid)) due += k.price;
            for (Payment p : dao.paymentsOfClinic(cl.uid)) paid += p.amount;
            totDue += due; totPaid += paid;
            rows.add(new CardAdapter.Row("\uD83D\uDC68\u200D\u2695\uFE0F " + cl.name,
                    getString(R.string.acc_short, Ui.money(due), Ui.money(paid)) + "\n\uD83D\uDCDE " + Ui.nz(cl.phone),
                    Ui.money(due - paid), due - paid > 0 ? 0xFFC62828 : 0xFF2E7D32));
        }
        header.setText(getString(R.string.acc_summary, Ui.money(totDue), Ui.money(totPaid), Ui.money(totDue - totPaid)));
        list.setAdapter(new CardAdapter(requireContext(), rows));
    }

    private void options(Clinic cl) {
        String[] items = {getString(R.string.opt_pay), getString(R.string.opt_send_updates),
                getString(R.string.btn_wa_doctor), getString(R.string.btn_call_doctor)};
        new AlertDialog.Builder(requireContext()).setTitle(cl.name).setItems(items, (d, w) -> {
            if (w == 0) addPayment(cl);
            else if (w == 1) Actions.sendUpdates(requireActivity(), cl);
            else if (w == 2) Ui.whatsapp(requireContext(), cl.phone, getString(R.string.msg_to_doctor_generic));
            else Ui.call(requireContext(), cl.phone);
        }).show();
    }

    private void addPayment(Clinic cl) {
        Ui.form(requireContext(), R.string.opt_pay, new int[]{R.string.hint_amount, R.string.hint_note}, f -> {
            double amount = Ui.num(f[0]);
            if (amount <= 0) return;
            Payment p = new Payment();
            p.uid = UUID.randomUUID().toString();
            p.clinicUid = cl.uid; p.amount = amount; p.note = f[1]; p.createdAt = System.currentTimeMillis();
            AppDatabase.get(requireContext()).dao().insertPayment(p);
            load();
        });
    }
}
