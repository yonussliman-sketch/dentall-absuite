package com.dentallab.lab;
import com.google.firebase.firestore.DocumentId;

public class InventoryItem {
    @DocumentId public String id;
    public String name;
    public int quantity;
    public InventoryItem() {}
}
