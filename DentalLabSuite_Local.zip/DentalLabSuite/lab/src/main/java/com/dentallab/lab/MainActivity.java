package com.dentallab.lab;
import android.content.Intent;
import androidx.fragment.app.Fragment;
import com.dentallab.core.*;

public class MainActivity extends BaseMainActivity {
    @Override public boolean isLab() { return true; }
    @Override protected int menuRes() { return R.menu.bottom_nav; }
    @Override protected int firstItemId() { return R.id.nav_home; }
    @Override public void openInventory() { startActivity(new Intent(this, InventoryActivity.class)); }

    @Override protected Fragment fragmentFor(int id) {
        if (id == R.id.nav_home) return new DashboardFragment();
        if (id == R.id.nav_cases) return new CasesFragment();
        if (id == R.id.nav_appts) return new AppointmentsFragment();
        if (id == R.id.nav_clinics) return new ClinicsFragment();
        return new MoreFragment();
    }
}
