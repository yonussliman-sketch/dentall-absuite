package com.dentallab.lab;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import com.dentallab.core.*;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.ListenerRegistration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** المخزون: اضغط لتعديل الكمية، اضغط مطولاً للحذف. يظهر تنبيه عند انخفاض الكمية */
public class InventoryFragment extends Fragment {
    private static final int LOW = 5;
    private ListView list;
    private ListenerRegistration reg;
    private List<InventoryItem> data = new ArrayList<>();

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup c, @Nullable Bundle s) {
        View v = inf.inflate(R.layout.fragment_list, c, false);
        list = v.findViewById(R.id.list);
        list.setEmptyView(v.findViewById(R.id.empty));
        ((FloatingActionButton) v.findViewById(R.id.fab)).setOnClickListener(x ->
            Ui.form(requireContext(), "مادة جديدة", new String[]{"اسم المادة", "الكمية"}, f -> {
                if (f[0].isEmpty()) return;
                InventoryItem i = new InventoryItem();
                i.name = f[0]; i.quantity = (int) Ui.num(f[1]);
                Repo.db().collection("inventory").add(i);
            }));
        list.setOnItemClickListener((p, view, pos, id) -> {
            InventoryItem i = data.get(pos);
            Ui.form(requireContext(), "تعديل كمية " + i.name, new String[]{"الكمية الجديدة"}, f ->
                    Repo.db().collection("inventory").document(i.id).update("quantity", (int) Ui.num(f[0])));
        });
        list.setOnItemLongClickListener((p, view, pos, id) -> {
            InventoryItem i = data.get(pos);
            new AlertDialog.Builder(requireContext()).setTitle("حذف " + i.name + "؟")
                    .setPositiveButton("حذف", (d, w) -> Repo.db().collection("inventory").document(i.id).delete())
                    .setNegativeButton("إلغاء", null).show();
            return true;
        });
        reg = Repo.db().collection("inventory").addSnapshotListener((snap, e) -> {
            if (snap == null || !isAdded()) return;
            data = snap.toObjects(InventoryItem.class);
            Collections.sort(data, (a, b) -> Ui.nz(a.name).compareTo(Ui.nz(b.name)));
            List<CardAdapter.Row> rows = new ArrayList<>();
            for (InventoryItem i : data)
                rows.add(new CardAdapter.Row(i.name, "اضغط للتعديل • اضغط مطولاً للحذف",
                        (i.quantity <= LOW ? "⚠ " : "") + i.quantity, i.quantity <= LOW ? 0xFFC62828 : 0xFF2E7D32));
            list.setAdapter(new CardAdapter(requireContext(), rows));
        });
        return v;
    }

    @Override public void onDestroyView() {
        if (reg != null) reg.remove();
        super.onDestroyView();
    }
}
