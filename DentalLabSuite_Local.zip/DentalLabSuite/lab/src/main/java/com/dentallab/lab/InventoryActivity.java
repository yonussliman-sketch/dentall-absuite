package com.dentallab.lab;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import com.dentallab.core.*;
import java.util.ArrayList;
import java.util.List;

/** المخزون: اضغط لتعديل الكمية، اضغط مطولاً للحذف. ⚠ عند انخفاض الكمية */
public class InventoryActivity extends AppCompatActivity {
    private static final int LOW = 5;
    private ListView list;
    private List<InventoryItem> data = new ArrayList<>();

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.fragment_list);
        Edge.apply(this);
        setTitle(R.string.more_inventory);
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        list = findViewById(R.id.list);
        list.setEmptyView(findViewById(R.id.empty));
        findViewById(R.id.fab).setOnClickListener(x ->
            Ui.form(this, R.string.inv_new, new int[]{R.string.hint_item_name, R.string.hint_qty}, f -> {
                if (f[0].isEmpty()) return;
                InventoryItem i = new InventoryItem();
                i.name = f[0]; i.quantity = (int) Ui.num(f[1]);
                AppDatabase.get(this).dao().insertItem(i);
                load();
            }));
        list.setOnItemClickListener((p, v, pos, id) -> {
            InventoryItem i = data.get(pos);
            Ui.form(this, R.string.inv_edit, new int[]{R.string.hint_qty}, f -> {
                i.quantity = (int) Ui.num(f[0]);
                AppDatabase.get(this).dao().updateItem(i);
                load();
            });
        });
        list.setOnItemLongClickListener((p, v, pos, id) -> {
            InventoryItem i = data.get(pos);
            Ui.confirm(this, R.string.confirm_delete, () -> { AppDatabase.get(this).dao().deleteItem(i); load(); });
            return true;
        });
        load();
    }

    private void load() {
        data = AppDatabase.get(this).dao().allItems();
        List<CardAdapter.Row> rows = new ArrayList<>();
        for (InventoryItem i : data)
            rows.add(new CardAdapter.Row(i.name, getString(R.string.inv_hint),
                    (i.quantity <= LOW ? "\u26A0 " : "") + i.quantity, i.quantity <= LOW ? 0xFFC62828 : 0xFF2E7D32));
        list.setAdapter(new CardAdapter(this, rows));
    }

    @Override public boolean onSupportNavigateUp() { finish(); return true; }
}
