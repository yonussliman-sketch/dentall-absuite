package com.dentallab.lab;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.dentallab.core.*;
import java.util.ArrayList;
import java.util.List;

/** لوحة المعلومات: نظرة سريعة على العمل */
public class DashboardFragment extends Fragment {
    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup c, @Nullable Bundle s) {
        View v = inf.inflate(R.layout.fragment_list, c, false);
        v.findViewById(R.id.fab).setVisibility(View.GONE);
        v.findViewById(R.id.empty).setVisibility(View.GONE);
        TextView h = v.findViewById(R.id.header);
        h.setVisibility(View.VISIBLE);
        h.setText(R.string.dash_title);
        h.setTextSize(18);
        ListView list = v.findViewById(R.id.list);

        AppDao dao = AppDatabase.get(requireContext()).dao();
        int[] cnt = new int[6];
        int urgent = 0;
        double due = 0, paid = 0;
        for (CaseItem k : dao.allCases()) {
            cnt[Math.max(0, Math.min(5, k.status))]++;
            if (k.urgent && k.status >= 1 && k.status < 5) urgent++;
            due += k.price;
        }
        for (Payment p : dao.allPayments()) paid += p.amount;
        int pending = 0;
        for (Appointment a : dao.allAppts()) if (a.status == 0) pending++;

        List<CardAdapter.Row> rows = new ArrayList<>();
        rows.add(new CardAdapter.Row("\uD83C\uDD95 " + getString(R.string.st_new), "", String.valueOf(cnt[1]), Ui.statusColor(1)));
        rows.add(new CardAdapter.Row("\uD83D\uDEE0 " + getString(R.string.st_progress), "", String.valueOf(cnt[2]), Ui.statusColor(2)));
        rows.add(new CardAdapter.Row("\uD83D\uDD0D " + getString(R.string.st_qc), "", String.valueOf(cnt[3]), Ui.statusColor(3)));
        rows.add(new CardAdapter.Row("\u2705 " + getString(R.string.st_ready), "", String.valueOf(cnt[4]), Ui.statusColor(4)));
        rows.add(new CardAdapter.Row("\u26A1 " + getString(R.string.dash_urgent), "", String.valueOf(urgent), 0xFFC62828));
        rows.add(new CardAdapter.Row("\uD83D\uDCC5 " + getString(R.string.dash_appts), "", String.valueOf(pending), Ui.apptColor(0)));
        rows.add(new CardAdapter.Row("\uD83C\uDFE5 " + getString(R.string.dash_clinics), "", String.valueOf(dao.allClinics().size()), 0xFF546E7A));
        rows.add(new CardAdapter.Row("\uD83D\uDCB0 " + getString(R.string.dash_balance),
                getString(R.string.acc_short, Ui.money(due), Ui.money(paid)), Ui.money(due - paid),
                due - paid > 0 ? 0xFFC62828 : 0xFF2E7D32));
        list.setAdapter(new CardAdapter(requireContext(), rows));
        return v;
    }
}
