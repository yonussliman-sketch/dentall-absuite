# Room يولّد الكود وقت البناء؛ لا قواعد إضافية مطلوبة
-keep class com.dentallab.core.TeethData { *; }
