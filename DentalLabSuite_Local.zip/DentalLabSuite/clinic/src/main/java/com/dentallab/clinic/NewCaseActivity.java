package com.dentallab.clinic;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.dentallab.core.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** إنشاء حالة جديدة: (اسم المريض اختياري) + نوع العمل + الأسنان من الفكين + اللون + ملفات بأي صيغة */
public class NewCaseActivity extends AppCompatActivity {
    private final List<Uri> uris = new ArrayList<>();
    private final List<String> names = new ArrayList<>();
    private final List<Long> sizes = new ArrayList<>();
    private TeethChartView chart;
    private LinearLayout filesBox;
    private TextView tvSelected;
    private Spinner spWork, spShade;
    private EditText etRef, etDue, etNotes;
    private CheckBox cbUrgent;

    private final ActivityResultLauncher<String[]> picker = registerForActivityResult(
            new ActivityResultContracts.OpenMultipleDocuments(), list -> {
                if (list == null) return;
                for (Uri u : list) {
                    try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
                    catch (Exception ignored) { }
                    uris.add(u);
                    names.add(FileStore.displayName(this, u));
                    sizes.add(FileStore.sizeOf(this, u));
                }
                renderFiles();
            });

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_new_case);
        Edge.apply(this);
        setTitle(R.string.btn_new_case);
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        etRef = findViewById(R.id.etRef);
        etDue = findViewById(R.id.etDue);
        etNotes = findViewById(R.id.etNotes);
        cbUrgent = findViewById(R.id.cbUrgent);
        spWork = findViewById(R.id.spWork);
        spShade = findViewById(R.id.spShade);
        chart = findViewById(R.id.teeth);
        filesBox = findViewById(R.id.filesBox);
        tvSelected = findViewById(R.id.tvSelected);

        spWork.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                getResources().getStringArray(R.array.work_types)));
        spShade.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, Ui.shades(this)));
        etDue.setOnClickListener(v -> Ui.pickDate(this, etDue::setText));
        chart.setListener(csv -> tvSelected.setText(csv.isEmpty() ? getString(R.string.teeth_none)
                : getString(R.string.teeth_selected, csv.replace(",", ", "))));
        findViewById(R.id.btnUpper).setOnClickListener(v -> chart.toggleJaw(true));
        findViewById(R.id.btnLower).setOnClickListener(v -> chart.toggleJaw(false));
        findViewById(R.id.btnClear).setOnClickListener(v -> chart.clear());
        findViewById(R.id.btnFiles).setOnClickListener(v -> picker.launch(new String[]{"*/*"}));
        findViewById(R.id.btnSave).setOnClickListener(v -> save(false));
        findViewById(R.id.btnSaveAdd).setOnClickListener(v -> save(true));
    }

    private void renderFiles() {
        filesBox.removeAllViews();
        for (int i = 0; i < uris.size(); i++) {
            final int idx = i;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(0, 10, 0, 10);
            TextView t = new TextView(this);
            t.setText("\uD83D\uDCC4 " + names.get(i) + "  (" + FileStore.human(sizes.get(i)) + ")");
            t.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView x = new TextView(this);
            x.setText("  \u2715  ");
            x.setTextSize(18);
            x.setOnClickListener(v -> { uris.remove(idx); names.remove(idx); sizes.remove(idx); renderFiles(); });
            row.addView(t);
            row.addView(x);
            filesBox.addView(row);
        }
    }

    private void save(boolean addAnother) {
        final String teeth = chart.getSelectedCsv();
        if (teeth.isEmpty()) { Ui.toast(this, R.string.err_teeth); return; }
        final CaseItem k = new CaseItem();
        k.uid = UUID.randomUUID().toString();
        k.clinicUid = Profile.uid(this);
        k.clinicName = Profile.name(this);
        k.clinicPhone = Profile.e164(this);
        k.patientRef = etRef.getText().toString().trim();
        k.workType = spWork.getSelectedItemPosition();
        k.teeth = teeth;
        k.shade = spShade.getSelectedItemPosition() == 0 ? "" : (String) spShade.getSelectedItem();
        k.dueDate = etDue.getText().toString();
        k.notes = etNotes.getText().toString().trim();
        k.urgent = cbUrgent.isChecked();
        k.status = 0;
        k.createdAt = System.currentTimeMillis();
        k.updatedAt = k.createdAt;

        final List<Uri> us = new ArrayList<>(uris);
        AlertDialog dlg = Ui.busy(this, R.string.msg_saving);
        Bg.run(() -> {
            List<FileStore.Item> items = new ArrayList<>();
            for (int i = 0; i < us.size(); i++) items.add(FileStore.copyIn(this, us.get(i), k.uid, i));
            k.filesJson = FileStore.toJson(items);
            AppDatabase.get(this).dao().insertCase(k);
            return Boolean.TRUE;
        }, (Boolean ok, Exception err) -> {
            dlg.dismiss();
            if (err != null) { Ui.toast(this, R.string.err_generic); return; }
            Ui.toast(this, R.string.toast_saved);
            if (addAnother) resetForm(); else finish();
        });
    }

    /** للحالة التالية: نحتفظ بنوع العمل واللون ونفرّغ الأسنان والملفات */
    private void resetForm() {
        chart.clear();
        uris.clear(); names.clear(); sizes.clear();
        renderFiles();
        etRef.setText("");
        etNotes.setText("");
        cbUrgent.setChecked(false);
        findViewById(R.id.etRef).requestFocus();
    }

    @Override public boolean onSupportNavigateUp() { finish(); return true; }
}
