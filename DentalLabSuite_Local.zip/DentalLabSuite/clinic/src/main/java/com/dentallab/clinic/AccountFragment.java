package com.dentallab.clinic;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.dentallab.core.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** حساب العيادة: المستحق والمدفوع والمتبقي (تُحدَّث عند استيراد ملف تحديثات المعمل) */
public class AccountFragment extends Fragment {
    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup c, @Nullable Bundle s) {
        View v = inf.inflate(R.layout.fragment_list, c, false);
        v.findViewById(R.id.fab).setVisibility(View.GONE);
        ListView list = v.findViewById(R.id.list);
        list.setEmptyView(v.findViewById(R.id.empty));
        TextView header = v.findViewById(R.id.header);
        header.setVisibility(View.VISIBLE);

        AppDao dao = AppDatabase.get(requireContext()).dao();
        double due = 0, paid = 0;
        List<Object[]> items = new ArrayList<>();
        for (CaseItem k : dao.allCases()) {
            if (k.price <= 0) continue;
            due += k.price;
            items.add(new Object[]{k.createdAt, new CardAdapter.Row(Ui.caseTitle(requireContext(), k, false),
                    Ui.money(k.price), Ui.statusLabel(requireContext(), k.status), Ui.statusColor(k.status))});
        }
        for (Payment p : dao.allPayments()) {
            paid += p.amount;
            items.add(new Object[]{p.createdAt, new CardAdapter.Row("\uD83D\uDCB5 " + Ui.money(p.amount),
                    Ui.nz(p.note), getString(R.string.acc_payment), 0xFF2E7D32)});
        }
        Collections.sort(items, (a, b) -> Long.compare((Long) b[0], (Long) a[0]));
        List<CardAdapter.Row> rows = new ArrayList<>();
        for (Object[] it : items) rows.add((CardAdapter.Row) it[1]);
        header.setText(getString(R.string.acc_summary, Ui.money(due), Ui.money(paid), Ui.money(due - paid)));
        list.setAdapter(new CardAdapter(requireContext(), rows));
        return v;
    }
}
