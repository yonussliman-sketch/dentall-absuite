package com.dentallab.clinic;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import com.dentallab.core.*;
import java.util.ArrayList;
import java.util.List;

public class NewOrderActivity extends AppCompatActivity {
    private final List<Uri> uris = new ArrayList<>();
    private final List<String> names = new ArrayList<>();
    private final List<Long> sizes = new ArrayList<>();
    private TeethChartView chart;
    private LinearLayout filesBox;
    private TextView tvSelected, tvProgress;
    private ProgressBar progress;
    private Button btnSend;
    private Spinner spWork, spShade;
    private EditText etPatient, etDue, etNotes;
    private CheckBox cbUrgent;

    private final ActivityResultLauncher<String[]> picker = registerForActivityResult(
            new ActivityResultContracts.OpenMultipleDocuments(), list -> {
                if (list == null) return;
                for (Uri u : list) {
                    try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
                    catch (Exception ignored) { }
                    uris.add(u);
                    names.add(FileUtil.name(this, u));
                    sizes.add(FileUtil.size(this, u));
                }
                renderFiles();
            });

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_new_order);
        setTitle("طلب جديد");
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        etPatient = findViewById(R.id.etPatient);
        etDue = findViewById(R.id.etDue);
        etNotes = findViewById(R.id.etNotes);
        cbUrgent = findViewById(R.id.cbUrgent);
        spWork = findViewById(R.id.spWork);
        spShade = findViewById(R.id.spShade);
        chart = findViewById(R.id.teeth);
        filesBox = findViewById(R.id.filesBox);
        tvSelected = findViewById(R.id.tvSelected);
        tvProgress = findViewById(R.id.tvProgress);
        progress = findViewById(R.id.progress);
        btnSend = findViewById(R.id.btnSend);

        spWork.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, Ui.WORK_TYPES));
        spShade.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, Ui.SHADES));
        etDue.setOnClickListener(v -> Ui.pickDate(this, etDue::setText));

        chart.setListener(csv -> tvSelected.setText(csv.isEmpty() ? "لم يتم اختيار أسنان" : "الأسنان المختارة: " + csv.replace(",", "، ")));
        findViewById(R.id.btnUpper).setOnClickListener(v -> chart.toggleJaw(true));
        findViewById(R.id.btnLower).setOnClickListener(v -> chart.toggleJaw(false));
        findViewById(R.id.btnClear).setOnClickListener(v -> chart.clear());
        findViewById(R.id.btnFiles).setOnClickListener(v -> picker.launch(new String[]{"*/*"}));
        btnSend.setOnClickListener(v -> send());
    }

    private void renderFiles() {
        filesBox.removeAllViews();
        for (int i = 0; i < uris.size(); i++) {
            final int idx = i;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(0, 8, 0, 8);
            TextView t = new TextView(this);
            t.setText("📄 " + names.get(i) + "  (" + FileUtil.human(sizes.get(i)) + ")");
            t.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup_WRAP, 1f));
            TextView x = new TextView(this);
            x.setText("  ✕  ");
            x.setTextSize(18);
            x.setOnClickListener(v -> { uris.remove(idx); names.remove(idx); sizes.remove(idx); renderFiles(); });
            row.addView(t);
            row.addView(x);
            filesBox.addView(row);
        }
    }
    private static final int ViewGroup_WRAP = android.view.ViewGroup.LayoutParams.WRAP_CONTENT;

    private void send() {
        String patient = etPatient.getText().toString().trim();
        if (patient.isEmpty()) { Ui.toast(this, "اكتب اسم المريض"); return; }
        if (chart.getSelectedCsv().isEmpty()) { Ui.toast(this, "اختر الأسنان من المخطط"); return; }
        btnSend.setEnabled(false);
        progress.setVisibility(View.VISIBLE);
        tvProgress.setVisibility(View.VISIBLE);
        uploadNext(0, new ArrayList<>(), patient);
    }

    private void uploadNext(int i, List<CaseFile> done, String patient) {
        if (i >= uris.size()) { saveOrder(patient, done); return; }
        tvProgress.setText("جاري رفع الملف " + (i + 1) + " من " + uris.size() + ": " + names.get(i));
        progress.setProgress(0);
        FileUtil.upload(this, uris.get(i), names.get(i), sizes.get(i), progress::setProgress, (f, err) -> {
            if (err != null) {
                btnSend.setEnabled(true);
                progress.setVisibility(View.GONE);
                tvProgress.setVisibility(View.GONE);
                Ui.toast(this, "فشل رفع الملف: " + err.getLocalizedMessage());
                return;
            }
            done.add(f);
            uploadNext(i + 1, done, patient);
        });
    }

    private void saveOrder(String patient, List<CaseFile> files) {
        tvProgress.setText("جاري إرسال الطلب...");
        Order o = new Order();
        o.clinicId = Repo.uid();
        o.clinicName = Session.name(this);
        o.clinicPhone = Session.phone(this);
        o.patientName = patient;
        o.workType = (String) spWork.getSelectedItem();
        o.teeth = chart.getSelectedCsv();
        o.shade = (String) spShade.getSelectedItem();
        o.dueDate = etDue.getText().toString();
        o.notes = etNotes.getText().toString().trim();
        o.urgent = cbUrgent.isChecked();
        o.status = Ui.STATUSES[0];
        o.createdAt = System.currentTimeMillis();
        o.files = files;
        Repo.db().collection("orders").add(o)
                .addOnSuccessListener(r -> { Ui.toast(this, "✅ تم إرسال الطلب للمعمل"); finish(); })
                .addOnFailureListener(e -> {
                    btnSend.setEnabled(true);
                    Ui.toast(this, "فشل الإرسال: " + e.getLocalizedMessage());
                });
    }

    @Override public boolean onSupportNavigateUp() { finish(); return true; }
}
