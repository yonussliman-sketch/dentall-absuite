package com.dentallab.clinic;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.dentallab.core.*;
import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {
    private boolean registerMode = false;
    private EditText etName, etPhone, etEmail, etPassword;
    private Button btnLogin, btnToggle;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Repo.auth().getCurrentUser() != null && Session.loggedIn(this)) { openMain(); return; }
        setContentView(R.layout.activity_login);
        etName = findViewById(R.id.etName);
        etPhone = findViewById(R.id.etPhone);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnToggle = findViewById(R.id.btnToggle);
        TextView contact = findViewById(R.id.tvContact);
        contact.setText("📞 " + Constants.CONTACT_TEXT);
        contact.setOnClickListener(v -> Ui.contactDialog(this, Constants.CONTACT_PHONE, "تواصل معنا"));

        btnToggle.setOnClickListener(v -> {
            registerMode = !registerMode;
            int vis = registerMode ? View.VISIBLE : View.GONE;
            etName.setVisibility(vis);
            etPhone.setVisibility(vis);
            btnLogin.setText(registerMode ? "إنشاء حساب" : "دخول");
            btnToggle.setText(registerMode ? "لديك حساب؟ سجّل الدخول" : "عيادة جديدة؟ أنشئ حساباً");
        });
        btnLogin.setOnClickListener(v -> submit());
    }

    private void submit() {
        String email = etEmail.getText().toString().trim();
        String pass = etPassword.getText().toString();
        String name = etName.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        if (email.isEmpty() || pass.length() < 6 || (registerMode && (name.isEmpty() || phone.isEmpty()))) {
            Ui.toast(this, "أكمل البيانات (كلمة المرور 6 أحرف على الأقل)");
            return;
        }
        btnLogin.setEnabled(false);
        if (registerMode) {
            Repo.auth().createUserWithEmailAndPassword(email, pass).addOnSuccessListener(r -> {
                Map<String, Object> u = new HashMap<>();
                u.put("name", name); u.put("phone", phone); u.put("role", "clinic"); u.put("email", email);
                Repo.db().collection("users").document(Repo.uid()).set(u)
                        .addOnSuccessListener(x -> { Session.save(this, name, "clinic", phone); openMain(); })
                        .addOnFailureListener(this::fail);
            }).addOnFailureListener(this::fail);
        } else {
            Repo.auth().signInWithEmailAndPassword(email, pass).addOnSuccessListener(r ->
                Repo.db().collection("users").document(Repo.uid()).get().addOnSuccessListener(s -> {
                    UserProfile p = s.toObject(UserProfile.class);
                    if (p == null || !"clinic".equals(p.role)) {
                        Repo.auth().signOut();
                        btnLogin.setEnabled(true);
                        Ui.toast(this, "هذا الحساب غير مخصص لتطبيق العيادات");
                        return;
                    }
                    Session.save(this, p.name, "clinic", Ui.nz(p.phone));
                    openMain();
                }).addOnFailureListener(this::fail)
            ).addOnFailureListener(this::fail);
        }
    }

    private void fail(Exception e) {
        btnLogin.setEnabled(true);
        Ui.toast(this, "خطأ: " + e.getLocalizedMessage());
    }
    private void openMain() { startActivity(new Intent(this, MainActivity.class)); finish(); }
}
