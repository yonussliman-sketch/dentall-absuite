package com.dentallab.clinic;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.dentallab.core.*;
import com.google.firebase.firestore.ListenerRegistration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** حساب العيادة: المستحق والمدفوع والمتبقي + سجل الحركات */
public class StatementFragment extends Fragment {
    private final List<Order> orders = new ArrayList<>();
    private final List<Payment> pays = new ArrayList<>();
    private ListenerRegistration r1, r2;
    private TextView header;
    private ListView list;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup c, @Nullable Bundle s) {
        View v = inf.inflate(R.layout.fragment_list, c, false);
        v.findViewById(R.id.fab).setVisibility(View.GONE);
        list = v.findViewById(R.id.list);
        list.setEmptyView(v.findViewById(R.id.empty));
        header = v.findViewById(R.id.header);
        header.setVisibility(View.VISIBLE);
        r1 = Repo.db().collection("orders").whereEqualTo("clinicId", Repo.uid()).addSnapshotListener((snap, e) -> {
            if (snap == null || !isAdded()) return;
            orders.clear(); orders.addAll(snap.toObjects(Order.class)); render();
        });
        r2 = Repo.db().collection("payments").whereEqualTo("clinicId", Repo.uid()).addSnapshotListener((snap, e) -> {
            if (snap == null || !isAdded()) return;
            pays.clear(); pays.addAll(snap.toObjects(Payment.class)); render();
        });
        return v;
    }

    private void render() {
        double due = 0, paid = 0;
        List<Object[]> items = new ArrayList<>();
        for (Order o : orders) {
            due += o.price;
            items.add(new Object[]{o.createdAt, new CardAdapter.Row("📄 " + o.patientName + " — " + Ui.nz(o.workType),
                    o.price > 0 ? "المبلغ: " + Ui.money(o.price) : "السعر لم يحدد بعد", o.status, Ui.statusColor(o.status))});
        }
        for (Payment p : pays) {
            paid += p.amount;
            items.add(new Object[]{p.createdAt, new CardAdapter.Row("💵 دفعة: " + Ui.money(p.amount),
                    Ui.nz(p.note), "مدفوع", 0xFF2E7D32)});
        }
        Collections.sort(items, (a, b) -> Long.compare((Long) b[0], (Long) a[0]));
        List<CardAdapter.Row> rows = new ArrayList<>();
        for (Object[] it : items) rows.add((CardAdapter.Row) it[1]);
        header.setText("المستحق: " + Ui.money(due) + "     المدفوع: " + Ui.money(paid)
                + "\nالمتبقي: " + Ui.money(due - paid));
        list.setAdapter(new CardAdapter(requireContext(), rows));
    }

    @Override public void onDestroyView() {
        if (r1 != null) r1.remove();
        if (r2 != null) r2.remove();
        super.onDestroyView();
    }
}
