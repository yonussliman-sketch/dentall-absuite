package com.dentallab.clinic;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.dentallab.core.*;

/** شاشة التواصل والاستفسار (آخر تبويب في التطبيق) */
public class ContactFragment extends Fragment {
    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup c, @Nullable Bundle s) {
        LinearLayout l = new LinearLayout(requireContext());
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        int p = (int) (28 * getResources().getDisplayMetrics().density);
        l.setPadding(p, p, p, p);

        TextView icon = new TextView(requireContext());
        icon.setText("📞");
        icon.setTextSize(56);
        icon.setGravity(Gravity.CENTER);

        TextView title = new TextView(requireContext());
        title.setText("للتواصل والاستفسار");
        title.setTextSize(22);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, android.graphics.Typeface.BOLD);

        TextView num = new TextView(requireContext());
        num.setText(Constants.CONTACT_PHONE);
        num.setTextSize(26);
        num.setGravity(Gravity.CENTER);
        num.setPadding(0, p / 2, 0, p);
        num.setTextColor(0xFF00796B);
        num.setTextDirection(View.TEXT_DIRECTION_LTR);

        Button wa = new Button(requireContext());
        wa.setText("💬 مراسلة عبر واتساب");
        wa.setOnClickListener(v -> Ui.whatsapp(requireContext(), Constants.CONTACT_PHONE, "السلام عليكم، لدي استفسار بخصوص طلب"));
        Button call = new Button(requireContext());
        call.setText("📞 اتصال مباشر");
        call.setOnClickListener(v -> Ui.call(requireContext(), Constants.CONTACT_PHONE));

        l.addView(icon);
        l.addView(title);
        l.addView(num);
        l.addView(wa, new LinearLayout.LayoutParams(-1, -2));
        l.addView(call, new LinearLayout.LayoutParams(-1, -2));
        return l;
    }
}
